﻿namespace Semestralka.Business;

public class Class1
{

}
