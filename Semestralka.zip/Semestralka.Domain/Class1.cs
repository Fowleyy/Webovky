﻿namespace Semestralka.Domain;

public class Class1
{

}
