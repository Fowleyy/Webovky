﻿namespace Semestralka.Data;

public class Class1
{

}
