namespace Semestralka.DTOs
{
    public class CalendarUpdateDto
    {
        public string? Color { get; set; }
        public string? Visibility { get; set; }
    }
}
