namespace Semestralka.DTOs
{
    public class CalendarCreateDto
    {
        public string? Color { get; set; }
        public string? Visibility { get; set; }
    }
}
