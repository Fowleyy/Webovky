namespace Semestralka.Application.DTOs.Calendar;

public class UpdateCalendarDto
{
    public string? Color { get; set; }
    public string? Visibility { get; set; }
}
